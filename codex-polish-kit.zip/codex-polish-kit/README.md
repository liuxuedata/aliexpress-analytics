
# Codex Polish Kit (drop-in)

A **10-minute facelift** for Codex-generated pages. No build tools required.

## Files
- `theme.css` → modern tokens, typography, cards, buttons, tables, forms, navbar, sidebar, utilities.
- `polish.js` → theme toggle + navbar shadow + KPI equal heights.

## How to use (static HTML / Vercel)
1. Drop both files somewhere public, e.g.
   - `public/assets/theme.css`
   - `public/assets/polish.js`
2. On every page (`index.html`, `independent-site.html`, `self-operated.html`, `login.html` …), right before `</head>` add:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="/assets/theme.css">
```

3. Right before `</body>` add:
```html
<script src="/assets/polish.js" defer></script>
```

4. Wrap your layout with the shell (optional but recommended):

```html
<header class="navbar">
  <div class="inner container">
    <div class="left"><a class="btn" href="/">Dashboard</a></div>
    <div class="right">
      <button class="btn" data-action="toggle-theme">Theme</button>
    </div>
  </div>
</header>

<div class="shell">
  <aside class="sidebar">
    <!-- your global/left nav -->
  </aside>
  <main class="main">
    <div class="container">
      <!-- page content -->
    </div>
  </main>
</div>
```

5. Convert existing metrics to KPI cards:

```html
<div class="kpis mt-8">
  <div class="kpi"><div class="label">Visitors</div><div class="value">12,340</div><div class="delta up">+7.2%</div></div>
  <div class="kpi"><div class="label">Add-to-Cart</div><div class="value">842</div><div class="delta up">+3.1%</div></div>
  <div class="kpi"><div class="label">Orders</div><div class="value">124</div><div class="delta down">-1.8%</div></div>
  <div class="kpi"><div class="label">Conversion</div><div class="value">1.02%</div></div>
</div>
```

6. Tables: add class `table` to your existing `<table>`. Forms: use class `input` on inputs/selects/textarea. Buttons: add class `btn` or `btn primary`.

## Notes
- Dark mode: add `data-theme="dark"` on `<html>` or click the "Theme" button.
- Doesn’t fight your existing CSS: tokens & utilities are namespaced; load **after** old CSS to take control.
- KPI grid auto-wraps (4 → 2 → 1).

## Commit message template for Codex
```
style: apply codex-polish-kit (tokens, cards, tables, dark mode)

- Add /assets/theme.css and /assets/polish.js
- Link theme.css after all previous styles in <head>
- Add navbar shell + sidebar layout wrappers
- Convert KPI area into `.kpis > .kpi` blocks (4 per row on desktop)
- Normalize tables with `.table`, inputs with `.input`, buttons with `.btn`
```
